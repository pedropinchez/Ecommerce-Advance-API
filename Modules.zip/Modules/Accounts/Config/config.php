<?php

return [
    'name' => 'Accounts'
];
