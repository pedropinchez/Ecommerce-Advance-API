<?php

namespace Modules\Document\Entities;

use Spatie\MediaLibrary\MediaCollections\Models\Media;

class MediaAttachment extends Media
{

}
