<?php

return [
    'name' => 'Supplier'
];
