<?php

namespace Modules\Coupon\Entities;

use Illuminate\Database\Eloquent\Model;

class CouponType extends Model
{
    protected $fillable = [];
}
