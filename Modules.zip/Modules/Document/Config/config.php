<?php

return [
    'name' => 'Document'
];
