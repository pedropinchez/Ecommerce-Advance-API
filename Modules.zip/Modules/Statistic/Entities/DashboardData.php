<?php

namespace Modules\Statistic\Entities;

class DashboardData
{

}
