<?php

return [
    'name' => 'Analytics'
];
