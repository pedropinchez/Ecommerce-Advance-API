<?php

namespace Modules\Referral\Entities;

use Illuminate\Database\Eloquent\Model;

class Referral extends Model
{
    protected $fillable = [];
}
