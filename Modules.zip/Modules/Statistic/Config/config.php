<?php

return [
    'name' => 'Statistic'
];
