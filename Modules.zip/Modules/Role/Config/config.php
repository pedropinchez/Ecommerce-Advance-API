<?php

return [
    'name' => 'Role'
];
