<?php

return [
    'name' => 'Item'
];
