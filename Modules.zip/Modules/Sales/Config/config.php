<?php

return [
    'name' => 'Sales'
];
