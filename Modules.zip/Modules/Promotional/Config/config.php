<?php

return [
    'name' => 'Promotional'
];
