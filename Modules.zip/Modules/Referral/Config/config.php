<?php

return [
    'name' => 'Referral'
];
